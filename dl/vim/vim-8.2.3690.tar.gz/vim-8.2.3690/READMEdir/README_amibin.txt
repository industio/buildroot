README_amibin.txt for version 8.2 of Vim: Vi IMproved.

See "README.txt" for general information about Vim.
See "README_ami.txt" for installation instructions for the Amiga.
These files are in the runtime archive (vim82rt.tgz).


The Amiga "bin" archive contains the Vim executable for the Amiga.  It was
compiled with "big" features.

Postscript printing is not included to avoid requiring floating point
computations.
