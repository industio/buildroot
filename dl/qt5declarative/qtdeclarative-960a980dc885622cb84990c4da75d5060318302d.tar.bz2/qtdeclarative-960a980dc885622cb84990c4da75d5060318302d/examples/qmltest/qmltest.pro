TEMPLATE = subdirs
SUBDIRS += qmltest
