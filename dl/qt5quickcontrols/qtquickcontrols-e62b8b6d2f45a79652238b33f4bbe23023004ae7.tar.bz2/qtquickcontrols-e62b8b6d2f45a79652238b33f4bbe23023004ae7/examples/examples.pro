TEMPLATE = subdirs
SUBDIRS = quickcontrols
