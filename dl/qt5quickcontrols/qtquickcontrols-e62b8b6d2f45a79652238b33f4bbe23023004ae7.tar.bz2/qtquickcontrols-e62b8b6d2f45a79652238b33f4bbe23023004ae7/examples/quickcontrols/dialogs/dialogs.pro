TEMPLATE = subdirs

SUBDIRS = \
    systemdialogs
