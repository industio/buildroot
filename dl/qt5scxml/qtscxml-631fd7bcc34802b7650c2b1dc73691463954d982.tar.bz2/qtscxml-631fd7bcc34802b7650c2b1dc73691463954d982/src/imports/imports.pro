TEMPLATE = subdirs
SUBDIRS = scxmlstatemachine

