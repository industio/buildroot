TEMPLATE = subdirs
SUBDIRS = qtquicktimeline
