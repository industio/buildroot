TEMPLATE = subdirs
SUBDIRS += \
    timeline
