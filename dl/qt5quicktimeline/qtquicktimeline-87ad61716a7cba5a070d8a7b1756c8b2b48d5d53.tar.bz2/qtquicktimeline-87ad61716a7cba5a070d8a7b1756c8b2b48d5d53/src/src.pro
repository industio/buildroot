TEMPLATE = subdirs
SUBDIRS += \
    imports
