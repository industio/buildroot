TEMPLATE = subdirs
SUBDIRS += shape
