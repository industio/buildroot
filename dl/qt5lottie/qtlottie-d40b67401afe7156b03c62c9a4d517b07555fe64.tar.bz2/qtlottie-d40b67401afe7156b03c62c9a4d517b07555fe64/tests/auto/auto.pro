TEMPLATE = subdirs
SUBDIRS += bodymovin
