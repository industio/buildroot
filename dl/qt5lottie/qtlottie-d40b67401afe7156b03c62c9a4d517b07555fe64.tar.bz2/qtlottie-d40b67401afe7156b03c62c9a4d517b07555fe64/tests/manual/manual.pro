TEMPLATE = subdirs
SUBDIRS += testApp
