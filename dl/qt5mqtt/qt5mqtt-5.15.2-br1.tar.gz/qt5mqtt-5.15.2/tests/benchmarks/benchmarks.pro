TEMPLATE = subdirs
SUBDIRS += qmqttclient

