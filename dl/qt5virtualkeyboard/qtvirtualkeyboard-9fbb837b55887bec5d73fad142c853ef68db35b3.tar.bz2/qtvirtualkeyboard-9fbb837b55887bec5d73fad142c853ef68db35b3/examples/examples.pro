TEMPLATE = subdirs

SUBDIRS += virtualkeyboard
