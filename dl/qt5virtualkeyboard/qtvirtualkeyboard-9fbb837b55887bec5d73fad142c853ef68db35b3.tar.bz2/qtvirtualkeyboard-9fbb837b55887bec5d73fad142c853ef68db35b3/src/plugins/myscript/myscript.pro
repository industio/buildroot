TEMPLATE = subdirs

SUBDIRS += \
    plugin
