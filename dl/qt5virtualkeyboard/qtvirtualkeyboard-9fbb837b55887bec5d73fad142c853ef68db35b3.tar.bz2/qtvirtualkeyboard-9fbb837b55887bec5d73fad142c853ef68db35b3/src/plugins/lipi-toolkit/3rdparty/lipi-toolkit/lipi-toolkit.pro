TEMPLATE = subdirs

SUBDIRS += \
    src
