TEMPLATE = subdirs

SUBDIRS = websockets
