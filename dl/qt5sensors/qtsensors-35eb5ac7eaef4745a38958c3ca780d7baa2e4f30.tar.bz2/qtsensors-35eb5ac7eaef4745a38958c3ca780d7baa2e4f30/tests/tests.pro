TEMPLATE = subdirs

SUBDIRS += auto
