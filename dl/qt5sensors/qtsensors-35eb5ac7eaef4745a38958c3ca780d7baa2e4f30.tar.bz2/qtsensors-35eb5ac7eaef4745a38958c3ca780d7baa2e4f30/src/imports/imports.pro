TEMPLATE = subdirs

SUBDIRS += sensors

