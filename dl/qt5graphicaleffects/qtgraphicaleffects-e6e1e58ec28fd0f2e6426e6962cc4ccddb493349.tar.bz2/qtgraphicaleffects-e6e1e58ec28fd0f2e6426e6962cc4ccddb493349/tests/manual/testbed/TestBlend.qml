/****************************************************************************
**
** Copyright (C) 2017 The Qt Company Ltd.
** Contact: https://www.qt.io/licensing/
**
** This file is part of the Qt Graphical Effects module.
**
** $QT_BEGIN_LICENSE:GPL-EXCEPT$
** Commercial License Usage
** Licensees holding valid commercial Qt licenses may use this file in
** accordance with the commercial license agreement provided with the
** Software or, alternatively, in accordance with the terms contained in
** a written agreement between you and The Qt Company. For licensing terms
** and conditions see https://www.qt.io/terms-conditions. For further
** information use the contact form at https://www.qt.io/contact-us.
**
** GNU General Public License Usage
** Alternatively, this file may be used under the terms of the GNU
** General Public License version 3 as published by the Free Software
** Foundation with exceptions as appearing in the file LICENSE.GPL3-EXCEPT
** included in the packaging of this file. Please review the following
** information to ensure the GNU General Public License requirements will
** be met: https://www.gnu.org/licenses/gpl-3.0.html.
**
** $QT_END_LICENSE$
**
****************************************************************************/

import QtQuick 2.12
import QtGraphicalEffects 1.12

TestCaseTemplate {
    ImageSource {
        id: imageSource1
        source: "images/bug.jpg"
    }

    ImageSource {
        id: imageSource2
        source: "images/butterfly.png"
    }

    Blend {
        id: effect
        anchors.fill: imageSource1
        visible: enabledCheckBox.selected
        cached: cachedCheckBox.selected
        source: imageSource1
        foregroundSource: imageSource2
        mode: blendMode.value
    }

    bgColor: bgColorPicker.color
    controls: [
        Control {
            caption: "general"

            RadioButtonColumn {
                id: blendMode
                value: "normal"
                caption: "mode"
                RadioButton {
                    caption: "normal"
                    selected: caption == blendMode.value
                    onPressedChanged: blendMode.value = caption
                }
                RadioButton {
                    caption: "addition"
                    selected: caption == blendMode.value
                    onPressedChanged: blendMode.value = caption
                }
                RadioButton {
                    caption: "average"
                    selected: caption == blendMode.value
                    onPressedChanged: blendMode.value = caption
                }
                RadioButton {
                    caption: "color"
                    selected: caption == blendMode.value
                    onPressedChanged: blendMode.value = caption
                }
                RadioButton {
                    caption: "colorBurn"
                    selected: caption == blendMode.value
                    onPressedChanged: blendMode.value = caption
                }
                RadioButton {
                    caption: "colorDodge"
                    selected: caption == blendMode.value
                    onPressedChanged: blendMode.value = caption
                }
                RadioButton {
                    caption: "darken"
                    selected: caption == blendMode.value
                    onPressedChanged: blendMode.value = caption
                }
                RadioButton {
                    caption: "darkerColor"
                    selected: caption == blendMode.value
                    onPressedChanged: blendMode.value = caption
                }
                RadioButton {
                    caption: "difference"
                    selected: caption == blendMode.value
                    onPressedChanged: blendMode.value = caption
                }
                RadioButton {
                    caption: "divide"
                    selected: caption == blendMode.value
                    onPressedChanged: blendMode.value = caption
                }
                RadioButton {
                    caption: "exclusion"
                    selected: caption == blendMode.value
                    onPressedChanged: blendMode.value = caption
                }
                RadioButton {
                    caption: "hardLight"
                    selected: caption == blendMode.value
                    onPressedChanged: blendMode.value = caption
                }
                RadioButton {
                    caption: "hue"
                    selected: caption == blendMode.value
                    onPressedChanged: blendMode.value = caption
                }
                RadioButton {
                    caption: "lighten"
                    selected: caption == blendMode.value
                    onPressedChanged: blendMode.value = caption
                }
                RadioButton {
                    caption: "lighterColor"
                    selected: caption == blendMode.value
                    onPressedChanged: blendMode.value = caption
                }
                RadioButton {
                    caption: "lightness"
                    selected: caption == blendMode.value
                    onPressedChanged: blendMode.value = caption
                }
                RadioButton {
                    caption: "multiply"
                    selected: caption == blendMode.value
                    onPressedChanged: blendMode.value = caption
                }
                RadioButton {
                    caption: "negation"
                    selected: caption == blendMode.value
                    onPressedChanged: blendMode.value = caption
                }
                RadioButton {
                    caption: "saturation"
                    selected: caption == blendMode.value
                    onPressedChanged: blendMode.value = caption
                }
                RadioButton {
                    caption: "screen"
                    selected: caption == blendMode.value
                    onPressedChanged: blendMode.value = caption
                }
                RadioButton {
                    caption: "softlight"
                    selected: caption == blendMode.value
                    onPressedChanged: blendMode.value = caption
                }
                RadioButton {
                    caption: "subtract"
                    selected: caption == blendMode.value
                    onPressedChanged: blendMode.value = caption
                }
            }
        },

        Control {
            caption: "advanced"
            last: true
            Label {
                caption: "Effect size"
                text: effect.width + "x" + effect.height
            }
            Label {
                caption: "FPS"
                text: fps
            }
            CheckBox {
                id: cachedCheckBox
                caption: "cached"
            }
            CheckBox {
                id: enabledCheckBox
                caption: "enabled"
            }
            CheckBox {
                id: updateCheckBox
                caption: "animated"
                selected: false
            }
            BGColorPicker {
                id: bgColorPicker
            }
        }
    ]
}
