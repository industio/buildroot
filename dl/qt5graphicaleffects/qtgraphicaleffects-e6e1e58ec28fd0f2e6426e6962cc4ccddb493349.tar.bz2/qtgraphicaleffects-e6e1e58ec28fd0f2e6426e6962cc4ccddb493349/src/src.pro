TEMPLATE = subdirs
SUBDIRS += effects
