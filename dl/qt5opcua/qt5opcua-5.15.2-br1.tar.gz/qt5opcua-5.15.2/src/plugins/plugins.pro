TEMPLATE = subdirs
SUBDIRS = opcua
