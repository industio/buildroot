TEMPLATE = subdirs
SUBDIRS = snippets
