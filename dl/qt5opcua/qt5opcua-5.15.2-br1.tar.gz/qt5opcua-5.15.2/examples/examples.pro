TEMPLATE = subdirs
SUBDIRS = opcua

