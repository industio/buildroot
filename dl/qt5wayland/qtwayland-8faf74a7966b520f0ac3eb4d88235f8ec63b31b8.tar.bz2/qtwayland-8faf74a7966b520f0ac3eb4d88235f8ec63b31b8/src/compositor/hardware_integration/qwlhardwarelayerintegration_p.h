/****************************************************************************
**
** Copyright (C) 2018 The Qt Company Ltd.
** Contact: https://www.qt.io/licensing/
**
** This file is part of the QtWaylandCompositor module of the Qt Toolkit.
**
** $QT_BEGIN_LICENSE:GPL$
** Commercial License Usage
** Licensees holding valid commercial Qt licenses may use this file in
** accordance with the commercial license agreement provided with the
** Software or, alternatively, in accordance with the terms contained in
** a written agreement between you and The Qt Company. For licensing terms
** and conditions see https://www.qt.io/terms-conditions. For further
** information use the contact form at https://www.qt.io/contact-us.
**
** GNU General Public License Usage
** Alternatively, this file may be used under the terms of the GNU
** General Public License version 3 or (at your option) any later version
** approved by the KDE Free Qt Foundation. The licenses are as published by
** the Free Software Foundation and appearing in the file LICENSE.GPL3
** included in the packaging of this file. Please review the following
** information to ensure the GNU General Public License requirements will
** be met: https://www.gnu.org/licenses/gpl-3.0.html.
**
** $QT_END_LICENSE$
**
****************************************************************************/

#ifndef QWAYLANDHARDWARELAYERINTEGRATION_H
#define QWAYLANDHARDWARELAYERINTEGRATION_H

//
//  W A R N I N G
//  -------------
//
// This file is not part of the Qt API.  It exists purely as an
// implementation detail.  This header file may change from version to
// version without notice, or even be removed.
//
// We mean it.
//

#include <QtWaylandCompositor/qtwaylandcompositorglobal.h>

#include <QObject>

QT_BEGIN_NAMESPACE

class QPoint;

class QWaylandQuickHardwareLayer;

namespace QtWayland {

class Q_WAYLAND_COMPOSITOR_EXPORT HardwareLayerIntegration : public QObject
{
    Q_OBJECT
public:
    HardwareLayerIntegration(QObject *parent = nullptr)
        : QObject(parent)
    {}
    ~HardwareLayerIntegration() override {}
    virtual void add(QWaylandQuickHardwareLayer *) {}
    virtual void remove(QWaylandQuickHardwareLayer *) {}
};

} // namespace QtWayland

QT_END_NAMESPACE

#endif // QWAYLANDHARDWARELAYERINTEGRATION_H
