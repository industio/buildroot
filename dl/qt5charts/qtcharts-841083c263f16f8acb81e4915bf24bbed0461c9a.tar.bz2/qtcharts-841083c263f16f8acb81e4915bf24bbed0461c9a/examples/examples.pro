TEMPLATE = subdirs
SUBDIRS += charts
