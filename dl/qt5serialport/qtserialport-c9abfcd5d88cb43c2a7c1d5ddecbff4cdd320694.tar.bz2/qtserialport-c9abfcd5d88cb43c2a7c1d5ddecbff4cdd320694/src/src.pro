TEMPLATE = subdirs

SUBDIRS = serialport
