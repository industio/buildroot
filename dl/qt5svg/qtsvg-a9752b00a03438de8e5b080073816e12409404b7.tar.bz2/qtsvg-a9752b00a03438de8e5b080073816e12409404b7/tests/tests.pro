TEMPLATE = subdirs
SUBDIRS +=  auto
