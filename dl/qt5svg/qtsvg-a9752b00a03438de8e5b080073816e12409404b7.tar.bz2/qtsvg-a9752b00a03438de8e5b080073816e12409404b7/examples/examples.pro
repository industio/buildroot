TEMPLATE = subdirs
SUBDIRS += svg
